# ICST: Information-Constrained Scalar-Tensor Theory

**Enformasyon-Kısıtlı Skaler-Tensör Teorisi (ICST)**  
Numerical codes and figures for the paper:

> *"Information-Constrained Scalar-Tensor Theory (ICST): Bekenstein-Hawking Bound, Metric Phase Transitions, and Informational Dynamics in Kerr Geometry"*

---

## Repository Structure

```
ICST-Theory-ICST2025/
├── README.md
├── requirements.txt
├── icst_ccrit.py              # C_crit analytic derivation & verification
├── icst_fig1_cassini.py       # Fig 1: Vainshtein screening, PPN (γ-1)
├── icst_fig2_geodesic.py      # Fig 2: Geodesic affine parameter, Kretschmann
├── icst_fig3_precision_eh98.py # Fig 3: Euclid 2026 power spectrum, Fisher matrix
├── icst_fig4_ccrit_derivation.py  # Fig 4: C_crit numerical derivation panels
├── icst_fig5_E_derivation.py  # Fig 5: E≈5.3 geometric derivation
├── icst_fig6_page_kerr.py     # Fig 6: Page curve & Kerr C-field profile
└── icst_paper_generator.py    # Full PDF generator (Turkish + English)
```

---

## Key Results

| Quantity | Value | Method |
|----------|-------|--------|
| C_crit | 1.1578 | Analytic: (1/2)ln(E²/4ln2) |
| E | ≈ 5.30 | Geometric: 1/√(H₀²l_P²Ω_Λ) |
| γ−1 (PPN) | ≈ 10⁻⁸ | Vainshtein screening |
| ΔP/P at k=0.15 h/Mpc | ≈ 1.8% | Euclid 2026 prediction |
| t_Page^ICST / t_Page^Schwarz | ≈ 0.67 | Disformal negative feedback |

---

## Installation

```bash
git clone https://github.com/ICST-Theory/ICST2025.git
cd ICST2025
pip install -r requirements.txt
```

## Usage

```bash
# Reproduce C_crit derivation
python icst_ccrit.py

# Generate all figures
python icst_fig1_cassini.py
python icst_fig2_geodesic.py
python icst_fig3_precision_eh98.py
python icst_fig4_ccrit_derivation.py
python icst_fig5_E_derivation.py
python icst_fig6_page_kerr.py

# Generate full paper PDF
python icst_paper_generator.py
```

---

## Citation

If you use this code, please cite:

```bibtex
@article{ICST2025,
  title   = {Information-Constrained Scalar-Tensor Theory (ICST):
             Bekenstein-Hawking Bound, Metric Phase Transitions,
             and Informational Dynamics in Kerr Geometry},
  author  = {ICST Theory Group},
  year    = {2025},
  note    = {Preprint}
}
```

---

## License

MIT License — see LICENSE file.
